

<?php $__env->startSection('content'); ?>


<div class="container">

<div class="container">
  <div class="row">
    <div class=" col-12 text-center mt-2">
    <h1 class="display-1">Les Etudiants</h1>
    </div>
  </div>
</div>
<hr>

    <table class="table table-striped">
        <thead class="thead-light">
            <tr>
                <th> Etudiant</th>
    
                <th>Ville</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $etudiants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><a href="<?php echo e(route('etudiant.show', $etudiant->id)); ?>"> <?php echo e($etudiant->nom); ?></a></td>
                <td><?php echo e($etudiant->etudiantHasVille->ville); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\e2194469\OneDrive - Collège de Maisonneuve\COURS\SEMESTER-4\cadriciel\TP_1\Maisonneuve2194469\resources\views/etudiant/index.blade.php ENDPATH**/ ?>