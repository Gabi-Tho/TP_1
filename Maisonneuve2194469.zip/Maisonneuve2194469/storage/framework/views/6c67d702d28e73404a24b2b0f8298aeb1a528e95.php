<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> TP1 Gabi</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Creepster&display=swap" rel="stylesheet"> 
</head>
<body>

<div class="card bg-dark text-white">
  <img class="img-fluid" src="<?php echo e(asset('css/img/background_3.jpg')); ?>"> 
  <div class="card-img-overlay">
    <h1 class="display-1 ">Maisonneuve</h1>
    <p class="lead">Un Projet encroyable de Laravel</p>
    <p class="lead">https://github.com/Gabi-Tho/TP_1</p>
    <nav class="position-absolute bottom-0 end-0 p-5 display-6">
      <a  class="text-decoration-none btn btn-light" href="<?php echo e(route('etudiant.index')); ?>">HOME</a>
    </nav>
  </div>
</div>

    <?php echo $__env->yieldContent('content'); ?>

    <footer class="text-center text-lg-start text-white">

    <div class="text-center p-3 primary">
      © 2023 Copyright:
      <a class="text-white" href="https://mdbootstrap.com/">Gabriela</a>
    </div>

  </footer>

</body>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
</html><?php /**PATH C:\Users\e2194469\OneDrive - Collège de Maisonneuve\COURS\SEMESTER-4\cadriciel\TP_1\Maisonneuve2194469\resources\views/layouts/app.blade.php ENDPATH**/ ?>