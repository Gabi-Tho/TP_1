<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Etudiants</title>
</head>
<body>
    <h3>list des etudiants</h3>
<table>
    <tr>
        <th>Etudiant</th>
        <th>Ville</th>
    </tr>
    <?php $__currentLoopData = $etudiants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($etudiant->nom); ?></td>
        <td><?php echo e($etudiant->ville_id); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>



</body>
</html><?php /**PATH C:\Users\e2194469\OneDrive - Collège de Maisonneuve\COURS\SEMESTER-4\cadriciel\TP_1\Maisonneuve2194469\resources\views/welcome.blade.php ENDPATH**/ ?>