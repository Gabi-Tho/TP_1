

<?php $__env->startSection('content'); ?>

<div class="container">
  <div class="row">
    <div class=" col-12 text-center mt-2">
    <h1 class="display-1">Edit Etudiant</h1>
    </div>
  </div>
</div>

<hr>

<hr>

<div class="container bg-light">


<form  method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>

  <div class="row">
    <div class="form-group col-md-6">
      <label for="nom">Nom</label>
      <input type="text" class="form-control" name="nom" id="exampleFormControlInput1" value="<?php echo e($etudiant->nom); ?>">
    </div>
    <div class="form-group col-md-6">
      <label for="email">Email</label>
      <input type="text" class="form-control" id="email" name="email" value="<?php echo e($etudiant->email); ?>">
    </div>
  </div>

  <div class="form-group">
    <label for="addresse">Addresse</label>
    <input type="text" class="form-control" id="addresse" name="addresse" value="<?php echo e($etudiant->addresse); ?>">
  </div>

  <div class="row">
    <div class="form-group col-md-6">
      <label for="phone">Phone</label>
      <input type="text" class="form-control" id="phone" name="phone" value="<?php echo e($etudiant->phone); ?>">
    </div>
  
    <div class="form-group col-md-6">
      <label for="date_naissance">Date de Naissance</label>
      <input type="text" class="form-control" id="date_naissance" name="date_naissance" value="<?php echo e($etudiant->date_naissance); ?>">
    </div>
  </div>
  

  

  <div class="form-group">
    <label for="ville_id">Ville</label>
    <select class="form-control" id="ville_id" name="ville_id">
        <option value="<?php echo e($etudiant->etudiantHasVille->ville); ?>" selected>
        <?php echo e($etudiant->etudiantHasVille->ville); ?>

        </option>
        <?php $__currentLoopData = $villes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ville): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($ville->id); ?>"><?php echo e($ville->ville); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>



<div class="d-flex align-items-center justify-content-center" style="height: 100px;">

<div class="px-2 ">
      <form action="<?php echo e(route('etudiant.edit', $etudiant->id)); ?>"method="post" >
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('put'); ?>
              <input type="submit" class="btn btn-success" value=" edit ">
      </form>
</div>

<div class="px-2 ">
  <form action="<?php echo e(route('etudiant.edit', $etudiant->id)); ?>"method="post">
          <?php echo csrf_field(); ?>
          <?php echo method_field('delete'); ?>
          <input type="submit" class="btn btn-danger" value="delete">
  </form>
</div>
    


</div>

</form>
</div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\e2194469\OneDrive - Collège de Maisonneuve\COURS\SEMESTER-4\cadriciel\TP_1\Maisonneuve2194469\resources\views/etudiant/edit.blade.php ENDPATH**/ ?>